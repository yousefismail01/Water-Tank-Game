#!/bin/bash

cp -r /home/codio/workspace/.guides/startup/. /home/codio/workspace/